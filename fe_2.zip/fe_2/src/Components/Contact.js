import React from 'react';
import Layout from './Layout';

const Contact=()=>{
    return(

<div>
    <Layout />
        Contact PAGE
    </div>
    )
    
}

export default Contact;